--2.1
use Northwind

--1
--select SUM(UnitPrice*Quantity - UnitPrice*Discount) as 'Totals'
--from [Order Details]

--2
--select sum(case when ShippedDate is null then 0 else 1 end)
--from Orders

--3
--select COUNT(distinct CustomerID)
--from Orders
