--1.4
use Northwind

select ProductName
from Products
where ProductName like '%cho%c%olade'