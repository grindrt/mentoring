--1.1
use Northwind

--1
--select CompanyName, Country
--from Customers
--where Country in ('USA', 'CANADA')
--order by CompanyName, Country

--2
--select CompanyName, Country
--from Customers
--where Country not in ('USA', 'CANADA')
--order by CompanyName

--3
--select distinct	Country
--from Customers
--order by Country desc
