﻿using System;
using ORMTask.Tasks;

namespace ORMTask
{
    class Program
    {
        static void Main(string[] args)
        {
	       // SecondTask.Do();
            ThirdTask.Do();

	        Console.ReadKey();
        }
    }
}
